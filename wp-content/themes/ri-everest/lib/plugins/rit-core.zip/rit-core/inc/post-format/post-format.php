<?php
/**
 * RIT Core Plugin
 * @package     RIT Core
 * @version     2.0.2
 * @author      Zootemplate
 * @link        http://www.zootemplate.com
 * @copyright   Copyright (c) 2015 Zootemplate
 * @license     GPL v2
 */

require_once RIT_PLUGIN_PATH . '/vendor/vafpress-post-formats-ui-develop/vp-post-formats-ui.php';